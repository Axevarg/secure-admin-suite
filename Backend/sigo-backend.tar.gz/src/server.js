import app from "./App.js";
import usersRoutes from "./routes/users.router.js";
import rolesRoutes from "./routes/roles.router.js";
import clientesRoutes from "./routes/clientes.routes.js";
import obrasRoutes from "./routes/obras.router.js";
import especialidadesRoutes from "./routes/especialidades.routes.js";


app.use("/roles", rolesRoutes);
app.use("/users", usersRoutes);
app.use("/clientes", clientesRoutes);
app.use("/obras", obrasRoutes);
app.use("/especialidades", especialidadesRoutes);

const PORT = 3000;

app.listen(PORT, () => {
  console.log("API running on port " + PORT);
});